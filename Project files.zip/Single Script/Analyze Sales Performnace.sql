/*Change over time*/
USE datawarehouseanalytics;
SELECT 
    YEAR(order_date) AS order_year,
    MONTH(order_date) AS order_month,
    SUM(sales_amount) AS total_sales,
    COUNT(DISTINCT customer_key) AS total_customers,
    SUM(quantity) AS total_quantity
FROM
    gold_fact_sales
WHERE
    order_date <> 0000 - 00 - 00 -- I also can use not in (0000-00-00)
GROUP BY YEAR(order_date) , MONTH(order_date)
ORDER BY YEAR(order_date) , MONTH(order_date);

/* Do same using datetrunc */
SELECT 
    DATE_FORMAT(order_date, '%Y-%b') AS order_date,
    SUM(sales_amount) AS total_sales,
    COUNT(DISTINCT customer_key) AS total_customers,
    SUM(quantity) AS total_quantity
FROM
    gold_fact_sales
WHERE
    order_date <> 0000 - 00 - 00
GROUP BY DATE_FORMAT(order_date, '%Y-%b')
ORDER BY DATE_FORMAT(order_date, '%Y-%b'); -- %b provide short form of month

/*You will notice that months are not in proper order for that's why use str_to_date*/

SELECT 
    DATE_FORMAT(order_date, '%Y-%m') AS order_date,
    SUM(sales_amount) AS total_sales,
    COUNT(DISTINCT customer_key) AS total_customers,
    SUM(quantity) AS total_quantity
FROM
    gold_fact_sales
WHERE
    order_date not in (0000-00-00)
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY order_date;


/* Cumulative Analysis */

-- calculate the total sales per month
-- and the running total of sales over time
-- we will use aggregate and windows function  
select 
order_date,
total_sales,
sum(total_sales) over (order by order_date) as running_total_sales
-- window function 
from (
SELECT 
    DATE_FORMAT(order_date, '%Y-%m') AS order_date, -- Doing same for the year just remove the -%m
    SUM(sales_amount) AS total_sales
FROM 
    gold_fact_sales
WHERE
    order_date not in (0000-00-00)
GROUP BY 
    DATE_FORMAT(order_date, '%Y-%m')
) as t;

-- Adding moving Average
select 
order_date,
total_sales,
sum(total_sales) over (order by order_date) as running_total_sales,
avg(avg_price) over (order by order_date) as moving_average_price

from (
SELECT 
    DATE_FORMAT(order_date, '%Y') AS order_date,
    SUM(sales_amount) AS total_sales,
    AVG(price) as avg_price
FROM 
    gold_fact_sales
WHERE
    order_date not in (0000-00-00)
GROUP BY 
    DATE_FORMAT(order_date, '%Y')
) t;

/* Performance Analysis */
-- Comparing the current value to target value
-- helps to measure success and compare the performance 
-- [current measure]  - [target measure ]
/* analyze the yearly performnace of products by comparing the products sales to both 
the average sales performance of the product and the previous year's sales*/
SELECT 
    YEAR(f.order_date) AS order_year,
    p.product_name,
    SUM(f.sales_amount) AS current_sales
FROM 
    gold_fact_sales f
LEFT JOIN 
    gold_dim_products p ON f.product_key = p.product_key
WHERE 
    f.order_date not in (0000-00-00)  
GROUP BY 
    YEAR(f.order_date),
    p.product_name
ORDER BY 
    YEAR(f.order_date); -- till now we have products yearly sales 

-- let's calculate the products average sales performance - Windows functions

WITH yearly_products_sales as (
SELECT 
    YEAR(f.order_date) AS order_year,
    p.product_name,
    SUM(f.sales_amount) AS current_sales
FROM 
    gold_fact_sales f
LEFT JOIN 
    gold_dim_products p ON f.product_key = p.product_key
WHERE 
    f.order_date not in (0000-00-00) 
GROUP BY 
    YEAR(f.order_date),
    p.product_name
)
select order_year,
product_name,
current_sales,
avg(current_sales) over (partition by product_name) avg_sales, 
current_sales - avg(current_sales) over (partition by product_name) sales_avg,
case when current_sales - avg(current_sales) over (partition by product_name) > 0 then 'Above Average'
	when current_sales - avg(current_sales) over (partition by product_name)< 0 then 'Below Average'
    else 'avg'
end avg_change
from yearly_products_sales
order by product_name, order_year;

-- previous year sales performance of product 
WITH yearly_products_sales as (
SELECT 
    YEAR(f.order_date) AS order_year,
    p.product_name,
    SUM(f.sales_amount) AS current_sales
FROM 
    gold_fact_sales f
LEFT JOIN 
    gold_dim_products p ON f.product_key = p.product_key
WHERE 
    f.order_date not in (0000-00-00) 
GROUP BY 
    YEAR(f.order_date),
    p.product_name
)
select order_year,
product_name,
current_sales,  -- you may add MAX(current_sales) OVER (partition by product_name) AS max_current_sales,
avg(current_sales) over (partition by product_name) avg_sales, 
current_sales - avg(current_sales) over (partition by product_name) sales_avg,
case when current_sales - avg(current_sales) over (partition by product_name) > 0 then 'Above Average'
	when current_sales - avg(current_sales) over (partition by product_name)< 0 then 'Below Average'
    else 'avg'
end avg_change,
-- year over year analysis
lag(current_sales) over (partition by product_name order by order_year) as py_sales, 
current_sales - lag(current_sales) over (partition by product_name order by order_year) as diff_py,
case when current_sales - lag(current_sales) over (partition by product_name order by order_year) > 0 then 'Increased' -- creating indigator
	when current_sales - lag(current_sales) over (partition by product_name order by order_year) < 0 then 'Decreased'
    else 'No change'
end sales_yoy_change
from yearly_products_sales
order by product_name, order_year;



/* Part - To - Whole Analysis - How individual part is performaing compared to overall, allow us to understand which category has the greatest impact on business */
-- [measure]/total[measure] * 100 by [Dimension]
-- ex - sales/total[sales] *100 by category 
-- which categories contribute the most to overall sales?
with category_sales as (
select 
category,
sum(sales_amount) as total_sales
from gold_fact_sales f 
left join gold_dim_products p
on p.product_key = f.product_key
group by category) -- to display aggregation at multiple levels in the results, use windows functions. 

select category,
total_sales,
sum(total_sales) over () as overall_sales,
concat(round((total_sales/ sum(total_sales) over ())*100,2), '%')as percentage_of_total
from category_sales
order by total_sales desc;

/* Data segmentation - Group the data based on specific range - helps to understand correlation bewteen two measures */
-- [measures] by [measures]
-- total products by sales range
-- total customers by age 
-- we use case when statements
-- segment products inot cost range and count how many produts fall into each segment 
with product_segments as (
select 
product_key,
product_name,
cost,
case when cost <100 then ' Below 100'
	 when cost between 100 and 500 then 'Btw 100-500'
     when cost between 500 and 1000 then 'Btw 500-1000'
     else 'above 1000'
end cost_range
from gold_dim_products 
Where cost not in (0))

select cost_range,
count(product_key) as total_products
from product_segments
group by cost_range
order by total_products desc;


/*Sql Task - Group customers into 3 segments based on their spending behaviour 
- VIP: at least 12 month of history and spending more than 5000, 
- regular: at least 12 months of history but spending 5000 or less 
- new: lifespan less then 12 months 
And find the total number of customers by each group */

with customer_spending as (
SELECT 
  c.customer_key, 
  SUM(f.sales_amount) AS total_spending, 
  MIN(order_date) AS first_order,
  MAX(order_date) AS last_order,
  TIMESTAMPDIFF(MONTH, MIN(order_date), MAX(order_date)) AS lifespan
FROM gold_fact_sales f
LEFT JOIN gold_dim_customers c 
  ON f.customer_key = c.customer_key
GROUP BY c.customer_key)

select 
customer_segment,
count(customer_key) as total_customer
from (
select 
customer_key, 
-- lifespan,
-- total_spending,
case when lifespan >= 12 and total_spending >= 5000 then 'VIP'
	 when lifespan >= 12 and total_spending <= 5000 then 'REGULAR'
     else 'NEW'
end customer_segment
from customer_spending) as t
group by customer_segment
order by total_customer desc;

/* build customer report 

Customer Report
----------------------------
This Report Consilidates Key Customer metrics and behaviours 
--Heighlights:
1. Gathers essential fields such as name, age and transaction details.
2. Segments customers into categories (VIP, Regular, New) and age groups.
3. Aggregates customer-level mertics:
	- total orders
    - total sales
    - total quantity purchased
    - total products
    - lifespan (in months)
4. Calculates valuable KPI's
	- recency (month since last order)
    - average order values
    - average monthly spend
------------------------------------------ */
Create View gold_report_customer as 
-- step 1 - Base query - Retrieves core columns from tables
with base_query as (
select 
f.order_number,
f.product_key,
f.order_date,
f.sales_amount,
f.quantity,
c.customer_key,
c.customer_number,
concat(c.first_name, ' ', c.last_name) as customer_name,
c.birthdate,
TIMESTAMPDIFF(YEAR, c.birthdate, CURDATE()) As age
from gold_fact_sales f
left join gold_dim_customers c
on c. customer_key = f.customer_key
where order_date not in (0000-00-00))

-- step 2 - Aggregates customer-level mertics
, customer_aggregation as (
select 
customer_key,
customer_number,
customer_name,
age,
count(distinct order_number) as total_orders,
sum(sales_amount) as total_sales,
sum(quantity) as total_quantity,
count(distinct product_key) as total_products,
max(order_date) as last_order_date,
TIMESTAMPDIFF(MONTH, MIN(order_date), MAX(order_date)) AS lifespan

from base_query
group by customer_key,
		 customer_number,
		 customer_name,
		 age)

-- Step 3 - Segment Customer into Categories (VIP, Regular, New)
select 
	customer_key,
	customer_number,
	customer_name,
	age,
    TIMESTAMPDIFF(Month, last_order_date , CURDATE()) As recency,    -- Step 4- Calculates valuable KPI's - recency (month since last order)
    case when age < 20 then 'Under_age'
		 when age between 20 and 29 then '20-29'
         when age between 30 and 39 then '30-39'
         when age between 40 and 49 then '40-49'
	     else '50 and above'
    end age_group,
    case when lifespan >=12 and total_sales > 5000 then 'VIP'
		 when lifespan >= 12 and total_sales <= 5000 then 'Regular'
         else 'New' 
	End as customer_segment,
    total_orders,
	total_sales,
	total_quantity,
	total_products,
    lifespan,
	last_order_date,
    
    -- step 4 - Calculates valuable KPI's - average order value 
    case when total_orders = 0 then 0
		 else ROUND(total_sales / total_orders, 2)
	end avg_order_value,
    -- Step 4 - Calculates valuable KPI's - average monthly spend
    Case when lifespan = 0 then total_sales
		 else round(total_sales/lifespan ,2) 
	end avg_monthly_spend
from customer_aggregation;

-- useing view for quick analyze
select
	age_group,
    customer_segment,
    count(customer_number) as total_customer,
    sum(total_sales) as total_sales
 from gold_report_customer
 Group by age_group, customer_segment
 order by age_group, customer_segment;

 

/* Build Product Report - This report consolidates key products metrics and behaviours.
	Highlights: 
			1. Generate Essential fields such as product name, category, sub-category, and cost.
            2. Segment products by revenue to identify High-performance, Average-performance, or Low-Performance.
            3. Aggregates Product-Level metrics:
			- total_orders
            - total_sales
            - total_quantity
            - total_customers (unique)
            - lifespan (months)
            4. Calculate Valueable KPI's
            - recency (months since last sale)
            - average order revenue(AOR)
            - average monthly revenue
*/
Create View gold_report_product as 
-- step 1 - Base query - Retrieves core columns from tables
with base_query as (
select 
f.order_number,
f.order_date,
f.customer_key,
f.sales_amount,
f.quantity,
p.product_key,
p.product_name,
p.category,
p.subcategory,
p.cost
from gold_fact_sales f
left join gold_dim_products p
on f.product_key = p.product_key
where order_date not in (0000-00-00))

-- step 2 - Aggregates customer-level mertics
,  product_aggregations as (
select 
product_key,
product_name,
category,
subcategory,
TIMESTAMPDIFF(MONTH, MIN(order_date), MAX(order_date)) AS lifespan,
MAX(order_date) as last_sales_date,
count(distinct order_number) as total_orders,
count(distinct customer_key) as total_customers,
sum(sales_amount) as total_sales,
sum(quantity) as total_quantity,
round(avg(sales_amount/nullif(quantity,0)), 2) as avg_selling_price
from base_query
group by product_key,
		 product_name,
		 category,
		 subcategory)

-- Step 3 - Segment product into Categories (High-performance, Average-performance, or Low-Performance)
select 
	product_key,
	product_name,
	category,
    subcategory,
    TIMESTAMPDIFF(Month, last_sales_date , CURDATE()) As recency_in_months,    -- Step 4- Calculates valuable KPI's - recency (month since last order)
    case when total_sales > 50000 then 'High-Performance'
		 when total_sales >= 10000 then 'Average-performance'
         else 'Low-performance' 
	End as product_segment,
    lifespan,
    total_orders,
	total_sales,
	total_quantity,
	total_customers,
    last_sales_date,
    avg_selling_price,

    -- step 4 - Calculates valuable KPI's - average order revenue
    case when total_orders = 0 then 0
		 else ROUND(total_sales / total_orders, 2)
	end as avg_order_revenue,
    -- Step 4 - Calculates valuable KPI's - average monthly revenue
    Case when lifespan = 0 then total_sales
		 else round(total_sales/lifespan ,2) 
	end as avg_monthly_revenue
    
from product_aggregations;

-- useing view for quick analyze
select
	category,
	product_segment,
    count(distinct product_key) as total_products,
    sum(total_sales) as total_sales
 from gold_report_product
 Group by category, product_segment
 order by category, product_segment;







