SET GLOBAL LOCAL_INFILE = ON;
LOAD DATA LOCAL INFILE 'D:/documents/Study/Data Analyst/SQL/sql-data-analytics-project/datasets/csv-files/golddim_customers.csv'
INTO TABLE gold_dim_customers
CHARACTER SET latin1
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES;
SELECT * FROM gold_dim_customers;

select count(*) from  gold_dim_customers;
